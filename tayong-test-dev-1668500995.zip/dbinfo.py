db_host = 'tayong.crdccaacc4cs.ap-northeast-2.rds.amazonaws.com'
db_username = 'admin'
db_password = 'answnsrl'
db_name = 'tayong'
db_port = 3306